import streamlit as st
import pandas as pd
import chromadb
import os
from langchain_huggingface import HuggingFaceEmbeddings


st.set_page_config(layout="wide")
@st.cache_resource
def read_data(file_path, k):
    data = pd.read_csv(file_path)
    data = data.drop(["id", "vote_count", 'status', 'revenue', 'popularity' ,'keywords', 'imdb_id'], axis=1)
    data = data.dropna(subset=['title' , 'genres', 'overview'], axis=0, how='any')

    data = data[:k]
    data_dicts = data.to_dict(orient="records")[:k]
    title = data.title[:k]

    st.session_state.data = data
    st.session_state.data_dicts =data_dicts
    st.session_state.title = title


@st.cache_resource
def to_lower(k, data_dicts):
    col = ['title' , 'genres', 'overview']
    for j in col:
        for i in range (len(data_dicts)):
            data_dicts[i][j]= data_dicts[i][j].lower()
            print(data_dicts[i][j])
    st.session_state.data_dicts= data_dicts



def get_embedding_model():
     embedding_model = HuggingFaceEmbeddings(model_name = "sentence-transformers/all-mpnet-base-v2" , model_kwargs={'device': 'cuda'})
     return embedding_model

@st.cache_resource
def make_database_and_get_collection(doc, data_dicts, k=2000 , batch_size = 500):
    client = chromadb.Client()
    client = chromadb.PersistentClient(path = "chromastore")
    if "movies" in client.list_collections():
        client.delete_collection("movies")
    collection = client.get_or_create_collection("movies")
    embedding_model = get_embedding_model()

    ids = [str(i) for i in range(k)]
    for i in range(0, k, batch_size):
        batch_texts = list(doc[i:i+batch_size])
        batch_ids = ids[i:i+batch_size]
        batch_metadatas = data_dicts[i:i+batch_size]
        to_embed = []
        print(i)
        
        for title , movie in zip(batch_texts, batch_metadatas):
            genre = movie.get('genre', 'N/A')
            overview = movie.get('overview', 'N/A')
            embedding_text = (
                f"Title: {title}. "
                f"Genres: {genre}. "
                f"Overview: {overview}. "
            )
            to_embed.append(embedding_text)
        embeddings = embedding_model.embed_documents(to_embed)

        collection.add(
            documents=batch_texts,
            embeddings=embeddings,
            metadatas=batch_metadatas,
            ids=batch_ids
        )
        st.session_state.collection = collection



def get_results(collection, query, n= 10):
    embedding_model = get_embedding_model()
    query_vec = embedding_model._embed([query] , encode_kwargs={'device':'cuda'})
    results = collection.query(query_embeddings=query_vec, n_results= n)
    return results



st.markdown("# 🎬**Movie Recommendation System**")

user_description = st.text_input( "### **Movie Finder:**",  placeholder="Describe the type of movie you want (e.g., a suspenseful 80s thriller about a computer hacker)..." ).lower()
n = st.text_input( "### **Number of Similar Movies:**", placeholder="E.g 5, 10, 15...")
button = st.button(label="Find Movies")

if button or 'collection' in st.session_state:
    if 'collection' not in st.session_state:
        if not os.path.exists('chromastore'):
            with st.spinner("🔄 Loading movie database... This may take a few minutes"):

                batch_size = 500
                file_path = "TMDB_movie_dataset_v11.csv"
                k = 5000
                read_data(file_path , k)
                doc = st.session_state.title
                data_dicts = st.session_state.data_dicts
                
                make_database_and_get_collection(doc, data_dicts, k, batch_size)

                st.success("✅ Database loaded successfully!")
        else:
            client = chromadb.Client()
            client = chromadb.PersistentClient(path = "chromastore")
            collection = client.get_or_create_collection("movies")
            st.session_state.collection = collection
    
    if button and user_description:
        with st.spinner("🔍 Finding similar movies..."):
            results = get_results(st.session_state.collection, user_description , int(n))
            top_docs = results['documents'][0]
            top_metas = results['metadatas'][0]
            top_ids = results['ids'][0]

            st.subheader("🎯 Movies similar to User's Description:")

            for rank, (doc, meta, id_) in enumerate(zip(top_docs, top_metas, top_ids), start=1):
                with st.container():
                    cols = st.columns([2, 5])
                    IMAGE_BASE_URL = "https://image.tmdb.org/t/p/"
                    size = 'original'
                    poster_path = meta.get('poster_path', None)
                    full_poster_url = f"{IMAGE_BASE_URL}{size}{poster_path}"

                    with cols[0]:
                        if full_poster_url:
                            st.image(full_poster_url, width=500)
                        else:
                            st.write("No image available")

                    with cols[1]:
                        st.markdown(f"""
                            <div style='font-size:26px; font-weight:700; margin-bottom:4px;'>
                                {rank}. {meta.get('title', 'N/A').title()}
                            </div>
                        """, unsafe_allow_html=True)

                        tagline = meta.get('tagline', '')
                        if tagline:
                            st.markdown(f"""
                                <div style='font-style:italic; color:gray; font-size:24px; margin-bottom:8px;'>
                                    {tagline}
                                </div>
                            """, unsafe_allow_html=True)

                        st.markdown(f"""
                            <div style='font-size:24px; line-height:1.6;'>
                                <b>Genres:</b> {meta.get('genres', 'N/A')}<br>
                                <b>Release Date:</b> {meta.get('release_date', 'N/A')}<br>
                                <b>Rating:</b> {meta.get('vote_average', 'N/A')}<br>
                                <b>Languages:</b> {meta.get('spoken_languages', 'N/A')}<br><br>
                                <b>Overview:</b> {meta.get('overview', 'N/A')}
                            </div>
                        """, unsafe_allow_html=True)

                    st.divider()

                    
                    
    elif button and not user_description:
        st.error('❌ Please enter a description')